import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

# Carga el conjunto de datos
df = pd.read_csv("/Users/sofia/Desktop/PredictGrades/Datos_De_Estudiantes.csv")

# Exploración de los datos
print(df.head())
print(df.describe())
print(df.info())

# Asegurarse de que no haya valores faltantes
print(df.isnull().sum())

# Transformación de datos categóricos en variables numéricas
df['Genero'] = df['Genero'].map({'Masculino': 0, 'Femenino': 1})
df['Estudia_con_Gratuidad'] = df['Estudia_con_Gratuidad'].map({'No': 0, 'Si': 1})
df['Problemas_Personales'] = df['Problemas_Personales'].map({'No': 0, 'Si': 1})
df['Problemas_Familiares'] = df['Problemas_Familiares'].map({'No': 0, 'Si': 1})
df['Participa_en_Clases'] = df['Participa_en_Clases'].map({'No': 0, 'Si': 1})
df['Trabaja'] = df['Trabaja'].map({'No': 0, 'Si': 1})

# Verifica las transformaciones
print(df.head())

# Separación de variables independientes (X) y dependiente (y)
X = df.drop("Promedio_Notas_Semestre_Anterior", axis=1)
y = df["Promedio_Notas_Semestre_Anterior"]

# División de los datos en conjuntos de entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

# Creación del modelo de regresión lineal
ridge_model = Ridge()

# Validación cruzada para evaluar el modelo
def evaluate_model(model, X_train, y_train):
    cv_scores = cross_val_score(model, X_train, y_train, cv=10, scoring='neg_mean_squared_error')
    cv_rmse = np.sqrt(-cv_scores)
    print(f"CV RMSE: {cv_rmse.mean()} ± {cv_rmse.std()}")
    model.fit(X_train, y_train)
    return model

ridge_model = evaluate_model(ridge_model, X_train, y_train)

# Evaluación del modelo
def model_performance(model, X_test, y_test):
    y_pred = model.predict(X_test)
    r2 = r2_score(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_test, y_pred)
    print(f"R^2: {r2}")
    print(f"Mean Squared Error: {mse}")
    print(f"Root Mean Squared Error: {rmse}")
    print(f"Mean Absolute Error: {mae}")
    return y_pred

print("Ridge Regression Performance:")
y_pred_ridge = model_performance(ridge_model, X_test, y_test)

# Visualización de resultados
plt.scatter(y_test, y_pred_ridge, label='Ridge', alpha=0.5)
plt.xlabel("Valores reales")
plt.ylabel("Predicciones")
plt.title("Valores reales vs Predicciones")
plt.legend()
plt.show()

# Coeficientes del modelo (derivadas parciales)
def print_coefficients(model, X):
    coefficients = pd.DataFrame(model.coef_, X.columns, columns=['Partial Derivative'])
    print("Coeficientes del modelo (derivadas parciales):")
    print(coefficients)

print("Ridge Regression Coefficients:")
print_coefficients(ridge_model, X)

# Análisis de derivadas para interpretar el impacto de cada variable independiente
def partial_derivatives(model, X):
    derivatives = model.coef_
    return pd.DataFrame(derivatives, index=X.columns, columns=['Partial Derivative'])


partials_ridge = partial_derivatives(ridge_model, X)

print("Ridge Regression Derivadas parciales calculadas:")
print(partials_ridge)


# Función para predecir el rendimiento académico
def predict_performance(student_data, model):
    student_df = pd.DataFrame(student_data, index=[0])
    student_df['Genero'] = student_df['Genero'].map({'Masculino': 0, 'Femenino': 1})
    student_df['Estudia_con_Gratuidad'] = student_df['Estudia_con_Gratuidad'].map({'No': 0, 'Si': 1})
    student_df['Problemas_Personales'] = student_df['Problemas_Personales'].map({'No': 0, 'Si': 1})
    student_df['Problemas_Familiares'] = student_df['Problemas_Familiares'].map({'No': 0, 'Si': 1})
    student_df['Participa_en_Clases'] = student_df['Participa_en_Clases'].map({'No': 0, 'Si': 1})
    student_df['Trabaja'] = student_df['Trabaja'].map({'No': 0, 'Si': 1})
    prediction = model.predict(student_df)
    return prediction

# Ejemplo de predicción
nuevo_estudiante = {
    "ID_estudiante": 31,
    "Edad": 21,
    "Genero": "Femenino",
    "%_Registro_Social_de_Hogares": 50,
    "Estudia_con_Gratuidad": "Si",
    "Promedio_de_%_Asistencia_del_Semestre_Anterior": 80,
    "Satisfaccion_con_la_Carrera": 4,
    "Nivel_de_Motivacion": 4,
    "Problemas_Personales": "No",
    "Problemas_Familiares": "No",
    "Horas_de_Sueno_Diarias": 7,
    "Participa_en_Clases": "Si",
    "Ultima_Nota_Obtenida": 5.0,
    "Ramos_Desaprobados": 0,
    "Trabaja": "No"
}

print(f"Predicción del ultimo promedio semestre anterior (Ridge): {predict_performance(nuevo_estudiante, ridge_model)[0]}")